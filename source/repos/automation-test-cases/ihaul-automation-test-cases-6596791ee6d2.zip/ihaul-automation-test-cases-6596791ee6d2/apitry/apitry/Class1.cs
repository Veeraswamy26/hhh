﻿namespace apitry
{
    public class Class1
    {

    }
}
