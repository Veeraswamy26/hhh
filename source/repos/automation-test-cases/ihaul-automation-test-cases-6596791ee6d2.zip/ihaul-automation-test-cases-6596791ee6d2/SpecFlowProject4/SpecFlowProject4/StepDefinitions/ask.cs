﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowProject4.StepDefinitions
{
   public class ask
    {
        public static void veera() {
            Console.WriteLine("yfytuhuib");
        }
    }
}
