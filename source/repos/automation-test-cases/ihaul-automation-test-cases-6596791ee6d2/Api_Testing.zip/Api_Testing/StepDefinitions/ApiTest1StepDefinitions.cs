using System;
using System.Net.Http;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using NUnit.Framework;
using TechTalk.SpecFlow.Infrastructure;
using System.ComponentModel;
using Newtonsoft.Json;
using Api_Testing.Support; // Ensure NUnit is used for assertions

namespace Api_Testing.StepDefinitions
{
    [Binding]
    public class ApiTest1StepDefinitions : DataModel
    {
        private readonly HttpClient httpClient;
        private HttpResponseMessage response;
        private string responsebody;
        private readonly ISpecFlowOutputHelper specFlowOutputHelper;

        public ApiTest1StepDefinitions(ISpecFlowOutputHelper specFlowOutputHelper)
        {
            this.specFlowOutputHelper = specFlowOutputHelper;
            httpClient = new HttpClient { BaseAddress = new Uri("https://reqres.in") }; // Set the BaseAddress to the base URL of the API you are testing
        }


        [Given(@"for http client")]
        public void GivenForHttpClient()
        {

        }




        [When(@"the user sends request wih url as ""([^""]*)""")]
        public async Task WhenTheUserSendsRequestWihUrlAs(string uri)
        {
            response = await httpClient.GetAsync(uri);
            response.EnsureSuccessStatusCode();
            responsebody = await response.Content.ReadAsStringAsync();
            specFlowOutputHelper.WriteLine(responsebody);

            var deserializedData = JsonConvert.DeserializeObject<DataModel.Rootobject>(responsebody);
            specFlowOutputHelper.WriteLine("After descerialisation of object value is :" + deserializedData.page.ToString());

            foreach (var item in deserializedData.data)
            {
                specFlowOutputHelper.WriteLine(item.first_name.ToString());

            }
        }




        [Then(@"the request should be succes with (.*)s code")]
        public async Task ThenTheRequestShouldBeSuccesWithSCode(int statusCode)
        {
            Assert.IsNotNull(response, "Response is null");
            Assert.AreEqual(statusCode, (int)response.StatusCode, $"Expected status code: {statusCode}, but got: {(int)response.StatusCode}");
        }
    }
}




